#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/lib"
XSLT_LIBS="-lxslt -lxml2 -lm "
XSLT_INCLUDEDIR="-I/usr/include"
MODULE_VERSION="xslt-1.1.32"
